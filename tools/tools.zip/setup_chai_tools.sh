#!/bin/bash


# Install the general dependencies
sudo apt-get update 
sudo apt-get -y upgrade
sudo apt-get install -y python-pip
sudo apt install -y virtualenv

#Activate CHai virtualenv
virtualenv chaidnn_tools_ENV
source ./chaidnn_tools_ENV/bin/activate

# Install binary specific dependencies
sudo apt-get install -y libprotobuf-dev libleveldb-dev libsnappy-dev libopencv-dev libhdf5-serial-dev protobuf-compiler
sudo apt-get install -y --no-install-recommends libboost-all-dev
sudo apt-get install -y libatlas-base-dev
sudo apt-get install -y libgflags-dev libgoogle-glog-dev liblmdb-dev 
for req in $(cat ./tools_binaries/python/requirements.txt); do pip install $req; done 

source ./chaidnn_tools_ENV/bin/activate &


