#!/usr/bin/env python
"""
quantize.py is an out-of-the-box network quantizer callable from the command line.

By default it configures and runs the Caffe reference ImageNet model.
"""

import numpy as np
import os
import sys
import argparse

import math
import collections
import scipy
import google.protobuf.text_format as tfmt
#import lmdb
import json

import caffe

def Trim2FixedPoint_cpu(data, bitwidth, threshold, f):
    scaling_factor = threshold / (pow(2, bitwidth - 1) - 1)
    data = np.clip(data, -threshold, threshold)
    if threshold != 0:
        data /= scaling_factor
        data = f(data)
        data *= scaling_factor
    return data

def cdf_measure(x, y, measure_name):
    if False:
        pass
    elif measure_name == "Kullback-Leibler-J":
        return np.sum((x - y) * np.log2(x / y))
    else:
        return cdf_measure(x, y, "Kullback-Leibler-J")

def compute_threshold(data, bitwidth, bins):
    mn = 0
    mx = np.abs(data).max()
    hist, bin_edges = np.histogram(np.abs(data), bins, range = (mn, mx), density = True)
    hist = hist / np.sum(hist)
    cumsum = np.cumsum(hist)

    n = pow(2, bitwidth - 1)
    threshold = []
    scaling_factor = []
    d = []

    #print "n: ", n, ", len(bin_edges): ", len(bin_edges)

    if n + 1 > len(bin_edges) - 1:
        th_layer_out = bin_edges[-1]
        sf_layer_out = th_layer_out / (pow(2, bitwidth - 1) - 1)
        #print "Mean : th_layer_out: ", th_layer_out, ", sf_layer_out: ", sf_layer_out
        return th_layer_out

    for i in range(n + 1, len(bin_edges), 1):
        threshold_tmp = (i + 0.5) * (bin_edges[1] - bin_edges[0])
        threshold = np.concatenate((threshold, [threshold_tmp]))
        scaling_factor_tmp = threshold_tmp / (pow(2, bitwidth - 1) - 1)
        scaling_factor = np.concatenate((scaling_factor, [scaling_factor_tmp]))

        p = np.copy(cumsum)
        p[i-1:] = 1

        x = np.linspace(0., 1., n)
        xp = np.linspace(0., 1., i)
        fp = p[:i]
        p_interp = np.interp(x, xp, fp)

        x = np.linspace(0., 1., i)
        xp = np.linspace(0., 1., n)
        fp = p_interp
        q_interp = np.interp(x, xp, fp)

        q = np.copy(p)
        q[:i] = q_interp

        d_tmp = cdf_measure(cumsum, q, "Kullback-Leibler-J")
        d = np.concatenate((d, [d_tmp]))

    th_layer_out = threshold[np.argmin(d)]
    sf_layer_out = scaling_factor[np.argmin(d)]
    #print "Mean : th_layer_out: ", th_layer_out, ", sf_layer_out: ", sf_layer_out
    return th_layer_out

def ThresholdLayerInputs_cpu(data, bitwidth):
    threshold = np.max(np.abs(data))
    return threshold

def ThresholdWeights_cpu(data, bitwidth):
    threshold = np.max(np.abs(data), axis=tuple(range(1, data.ndim)))
    threshold = np.where(threshold > np.finfo(np.float32).eps * np.max(threshold), threshold, 0)
    return threshold

def ThresholdBiases_cpu(data, bitwidth):
    threshold = np.max(np.abs(data), axis=tuple(range(1, data.ndim)))
    threshold = np.where(threshold > np.finfo(np.float32).eps * np.max(threshold), threshold, 0)
    return threshold

def ThresholdLayerOutputs_cpu(data, bitwidth):
    threshold = compute_threshold(data.flatten(), bitwidth, "sqrt")
    return threshold

def quantize_input(name, net, net_parameter, bw_layer_out_global, bw_layer_out, th_layer_out):
    # Inputs
    pass

    # Execute
    net.forward(start = name, end = name)

    # Outputs
    data = net.blobs[net.top_names[name][0]].data[...]
    bitwidth = bw_layer_out_global
    threshold = ThresholdLayerOutputs_cpu(data, bitwidth)

    bw_layer_out[net.top_names[name][0]] = bw_layer_out_global
    th_layer_out[net.top_names[name][0]] = threshold

    net.blobs[net.top_names[name][0]].data[:] = Trim2FixedPoint_cpu(data, bitwidth, threshold, np.round)

    print "bw_layer_out: ", bw_layer_out[net.top_names[name][0]]
    print "th_layer_out: ", th_layer_out[net.top_names[name][0]]

    L = next(L for L in net_parameter.layer if L.name == name)
    L.quantization_param.bw_layer_out = bw_layer_out[net.top_names[name][0]]
    L.quantization_param.th_layer_out = th_layer_out[net.top_names[name][0]]
    return net, bw_layer_out, th_layer_out

def quantize_convolution(name, net, net_parameter, bw_layer_in, th_layer_in, bw_layer_out, th_layer_out, bw_params, th_params, bw_params_global, bw_layer_out_global):
    # Inputs
    data = net.blobs[net.bottom_names[name][0]].data[...]
    bitwidth = bw_layer_out[net.bottom_names[name][0]]
    threshold = th_layer_out[net.bottom_names[name][0]]

    bw_layer_in[net.top_names[name][0]] = bitwidth
    th_layer_in[net.top_names[name][0]] = threshold

    net.blobs[net.bottom_names[name][0]].data[:] = Trim2FixedPoint_cpu(data, bitwidth, threshold, np.round)

    # Weights
    data = net.params[name][0].data[...]
    bitwidth = bw_params_global
    threshold = ThresholdWeights_cpu(data, bitwidth)

    bw_params[net.top_names[name][0]] = bitwidth
    th_params[net.top_names[name][0]] = threshold

    for i in range(len(th_params[net.top_names[name][0]])):
        net.params[name][0].data[i] = Trim2FixedPoint_cpu(data[i], bitwidth, threshold[i], np.round)

    # Execute
    net.forward(start = name, end = name)

    # Outputs
    data = net.blobs[net.top_names[name][0]].data[...]
    bitwidth = bw_layer_out_global
    threshold = ThresholdLayerOutputs_cpu(data, bitwidth)

    bw_layer_out[net.top_names[name][0]] = bitwidth
    th_layer_out[net.top_names[name][0]] = threshold

    net.blobs[net.top_names[name][0]].data[:] = Trim2FixedPoint_cpu(data, bitwidth, threshold, np.round)

    print "bw_layer_in: ", bw_layer_in[net.top_names[name][0]]
    print "th_layer_in: ", th_layer_in[net.top_names[name][0]]

    L = next(L for L in net_parameter.layer if L.name == name)
    L.quantization_param.quant_type = "Offline"
    L.quantization_param.bw_layer_in = bw_layer_in[net.top_names[name][0]]
    L.quantization_param.th_layer_in = th_layer_in[net.top_names[name][0]]

    print "bw_layer_out: ", bw_layer_out[net.top_names[name][0]]
    print "th_layer_out: ", th_layer_out[net.top_names[name][0]]

    L = next(L for L in net_parameter.layer if L.name == name)
    L.quantization_param.bw_layer_out = bw_layer_out[net.top_names[name][0]]
    L.quantization_param.th_layer_out = th_layer_out[net.top_names[name][0]]

#    print "bw_params: ", bw_params[net.top_names[name][0]]
#    for i in range(len(th_params[net.top_names[name][0]])):
#        print "th_params: ", th_params[net.top_names[name][0]][i]

    L = next(L for L in net_parameter.layer if L.name == name)
    L.quantization_param.bw_params = bw_params[net.top_names[name][0]]
    L.quantization_param.th_params[:] = th_params[net.top_names[name][0]].astype(float)

    #L.type = "ConvolutionRistretto"
    threshold_match_checker(th_layer_in[net.top_names[name][0]], th_layer_out[net.bottom_names[name][0]], name)
    return net, bw_layer_in, th_layer_in, bw_layer_out, th_layer_out, bw_params, th_params


def quantize_batchnorm(name, net, net_parameter, bw_layer_in, th_layer_in, bw_layer_out, th_layer_out, bw_params, th_params, th_params_var, bw_params_global, bw_layer_out_global):
    
    # Inputs
    data_in = net.blobs[net.bottom_names[name][0]].data[...]
    bitwidth = bw_layer_out[net.bottom_names[name][0]]
    threshold = th_layer_out[net.bottom_names[name][0]]

    bw_layer_in[net.top_names[name][0]] = bitwidth
    th_layer_in[net.top_names[name][0]] = threshold
    
    # Trim Input
    net.blobs[net.bottom_names[name][0]].data[:] = Trim2FixedPoint_cpu(data_in, bitwidth, threshold, np.round)
      
    # Mean data and the input to BN should be scaled with the sf_in
    # threshold for Mean data is calculated and stored in th_params
    data = net.params[name][0].data[...]
    bitwidth = bw_params_global
    threshold_mean = ThresholdWeights_cpu(data, bitwidth)
    
    ## Replicate the threshold_in for mean threshold per channel
    for i in range(len(net.params[name][0].data[...])):#len(net.params[name][0].data[...])):
        threshold_mean[i] = threshold
    
    
    bw_params[net.top_names[name][0]] = bitwidth
    th_params[net.top_names[name][0]] = threshold_mean
    
    # Trim the Mean data
    for i in range(len(net.params[name][0].data[...])):#len(net.params[name][0].data[...])):
        net.params[name][0].data[i] = Trim2FixedPoint_cpu(data[i], bitwidth, threshold , np.round)# th_layer_in[net.top_names[name][0]]
     
    
    
    ## Trim Data-in 
    #for i in range(len(th_params[net.top_names[name][0]])):
        #net.blobs[net.bottom_names[name][0]].data[:i::] = Trim2FixedPoint_cpu(data_in, bitwidth, threshold[i], np.round)
    

    
    # Bias data (Variance) is used to calculate the th_params_var
    data = net.params[name][1].data[...]
    data1 = np.divide(1, data)
    threshold = ThresholdWeights_cpu(data1, bitwidth)
    th_params_var[net.top_names[name][0]] = threshold    
    
    ## Trim the Variance data
    #for i in range(len(th_params_var[net.top_names[name][0]])):
        #net.params[name][1].data[i] = Trim2FixedPoint_cpu(data[i], bitwidth, threshold[i], np.round)
        

    # Execute
    net.forward(start = name, end = name)

    # Outputs
    data = net.blobs[net.top_names[name][0]].data[...]
    bitwidth = bw_layer_out_global
    threshold = ThresholdLayerOutputs_cpu(data, bitwidth)

    bw_layer_out[net.top_names[name][0]] = bitwidth
    th_layer_out[net.top_names[name][0]] = threshold

    net.blobs[net.top_names[name][0]].data[:] = Trim2FixedPoint_cpu(data, bitwidth, threshold, np.round)

    print "bw_layer_in: ", bw_layer_in[net.top_names[name][0]]
    print "th_layer_in: ", th_layer_in[net.top_names[name][0]]

    L = next(L for L in net_parameter.layer if L.name == name)
    L.quantization_param.quant_type = "Offline"
    L.quantization_param.bw_layer_in = bw_layer_in[net.top_names[name][0]]
    L.quantization_param.th_layer_in = th_layer_in[net.top_names[name][0]]

    print "bw_layer_out: ", bw_layer_out[net.top_names[name][0]]
    print "th_layer_out: ", th_layer_out[net.top_names[name][0]]

    L = next(L for L in net_parameter.layer if L.name == name)
    L.quantization_param.bw_layer_out = bw_layer_out[net.top_names[name][0]]
    L.quantization_param.th_layer_out = th_layer_out[net.top_names[name][0]]

#    print "bw_params: ", bw_params[net.top_names[name][0]]
#    for i in range(len(th_params[net.top_names[name][0]])):
#        print "th_params: ", th_params[net.top_names[name][0]][i]

    L = next(L for L in net_parameter.layer if L.name == name)
    L.quantization_param.bw_params = bw_params[net.top_names[name][0]]
    L.quantization_param.th_params[:] = th_params[net.top_names[name][0]].astype(float)
    #L.quantization_param.th_params_var[:] = th_params_var[net.top_names[name][0]].astype(float)

    #L.type = "BatchNormRistretto"
    threshold_match_checker(th_layer_in[net.top_names[name][0]], th_layer_out[net.bottom_names[name][0]], name)
    return net, bw_layer_in, th_layer_in, bw_layer_out, th_layer_out, bw_params, th_params

def quantize_scale(name, net, net_parameter, bw_layer_in, th_layer_in, bw_layer_out, th_layer_out, bw_params, th_params, bw_params_global, bw_layer_out_global):
    # Inputs
    data = net.blobs[net.bottom_names[name][0]].data[...]
    bitwidth = bw_layer_out[net.bottom_names[name][0]]
    threshold = th_layer_out[net.bottom_names[name][0]]

    bw_layer_in[net.top_names[name][0]] = bitwidth
    th_layer_in[net.top_names[name][0]] = threshold

    net.blobs[net.bottom_names[name][0]].data[:] = Trim2FixedPoint_cpu(data, bitwidth, threshold, np.round)

    # Weights
    data = net.params[name][0].data[...]
    bitwidth = bw_params_global
    threshold = ThresholdWeights_cpu(data, bitwidth)

    bw_params[net.top_names[name][0]] = bitwidth
    th_params[net.top_names[name][0]] = threshold

    for i in range(len(th_params[net.top_names[name][0]])):
        net.params[name][0].data[i] = Trim2FixedPoint_cpu(data[i], bitwidth, threshold[i], np.round)

    # Execute
    net.forward(start = name, end = name)

    # Outputs
    data = net.blobs[net.top_names[name][0]].data[...]
    bitwidth = bw_layer_out_global
    threshold = ThresholdLayerOutputs_cpu(data, bitwidth)

    bw_layer_out[net.top_names[name][0]] = bitwidth
    th_layer_out[net.top_names[name][0]] = threshold

    net.blobs[net.top_names[name][0]].data[:] = Trim2FixedPoint_cpu(data, bitwidth, threshold, np.round)

    print "bw_layer_in: ", bw_layer_in[net.top_names[name][0]]
    print "th_layer_in: ", th_layer_in[net.top_names[name][0]]

    L = next(L for L in net_parameter.layer if L.name == name)
    L.quantization_param.quant_type = "Offline"
    L.quantization_param.bw_layer_in = bw_layer_in[net.top_names[name][0]]
    L.quantization_param.th_layer_in = th_layer_in[net.top_names[name][0]]

    print "bw_layer_out: ", bw_layer_out[net.top_names[name][0]]
    print "th_layer_out: ", th_layer_out[net.top_names[name][0]]

    L = next(L for L in net_parameter.layer if L.name == name)
    L.quantization_param.bw_layer_out = bw_layer_out[net.top_names[name][0]]
    L.quantization_param.th_layer_out = th_layer_out[net.top_names[name][0]]

#    print "bw_params: ", bw_params[net.top_names[name][0]]
#    for i in range(len(th_params[net.top_names[name][0]])):
#        print "th_params: ", th_params[net.top_names[name][0]][i]

    L = next(L for L in net_parameter.layer if L.name == name)
    L.quantization_param.bw_params = bw_params[net.top_names[name][0]]
    L.quantization_param.th_params[:] = th_params[net.top_names[name][0]].astype(float)

    #L.type = "ScaleRistretto"
    threshold_match_checker(th_layer_in[net.top_names[name][0]], th_layer_out[net.bottom_names[name][0]], name)
    return net, bw_layer_in, th_layer_in, bw_layer_out, th_layer_out, bw_params, th_params


def quantize_inner_product(name, net, net_parameter, bw_layer_in, th_layer_in, bw_layer_out, th_layer_out, bw_params, th_params, bw_params_global, bw_layer_out_global):
    # Inputs
    data = net.blobs[net.bottom_names[name][0]].data[...]
    bitwidth = bw_layer_out[net.bottom_names[name][0]]
    threshold = th_layer_out[net.bottom_names[name][0]]

    bw_layer_in[net.top_names[name][0]] = bitwidth
    th_layer_in[net.top_names[name][0]] = threshold

    net.blobs[net.bottom_names[name][0]].data[:] = Trim2FixedPoint_cpu(data, bitwidth, threshold, np.round)

    # Weights
    data = net.params[name][0].data[...]
    bitwidth = bw_params_global
    threshold = ThresholdWeights_cpu(data, bitwidth)

    bw_params[net.top_names[name][0]] = bitwidth
    th_params[net.top_names[name][0]] = threshold

    for i in range(len(th_params[net.top_names[name][0]])):
        net.params[name][0].data[i] = Trim2FixedPoint_cpu(data[i], bitwidth, threshold[i], np.round)

    # Execute
    net.forward(start = name, end = name)

    # Outputs
    data = net.blobs[net.top_names[name][0]].data[...]
    bitwidth = bw_layer_out_global
    threshold = ThresholdLayerOutputs_cpu(data, bitwidth)

    bw_layer_out[net.top_names[name][0]] = bitwidth
    th_layer_out[net.top_names[name][0]] = threshold

    net.blobs[net.top_names[name][0]].data[:] = Trim2FixedPoint_cpu(data, bitwidth, threshold, np.round)

    #print "bw_layer_in: ", bw_layer_in[net.top_names[name][0]]
    #print "th_layer_in: ", th_layer_in[net.top_names[name][0]]

    #L = next(L for L in net_parameter.layer if L.name == name)
    #L.quantization_param.bw_layer_in = bw_layer_in[net.top_names[name][0]]
    #L.quantization_param.th_layer_in = th_layer_in[net.top_names[name][0]]

    #print "bw_layer_out: ", bw_layer_out[net.top_names[name][0]]
    #print "th_layer_out: ", th_layer_out[net.top_names[name][0]]

    #L = next(L for L in net_parameter.layer if L.name == name)
    #L.quantization_param.bw_layer_out = bw_layer_out[net.top_names[name][0]]
    #L.quantization_param.th_layer_out = th_layer_out[net.top_names[name][0]]

    #L = next(L for L in net_parameter.layer if L.name == name)
    #L.quantization_param.bw_params = bw_params[net.top_names[name][0]]
    #L.quantization_param.th_params[:] = th_params[net.top_names[name][0]].astype(float)

    #L.type = "FcRistretto"
    threshold_match_checker(th_layer_in[net.top_names[name][0]], th_layer_out[net.bottom_names[name][0]], name)
    return net, bw_layer_in, th_layer_in, bw_layer_out, th_layer_out, bw_params, th_params

def quantize_relu(name, net, net_parameter, bw_layer_in, th_layer_in, bw_layer_out, th_layer_out, bw_layer_out_global):
    # Inputs
    data = net.blobs[net.bottom_names[name][0]].data[...]
    bitwidth = bw_layer_out[net.bottom_names[name][0]]
    threshold = th_layer_out[net.bottom_names[name][0]]

    bw_layer_in[net.top_names[name][0]] = bitwidth
    th_layer_in[net.top_names[name][0]] = threshold

    net.blobs[net.bottom_names[name][0]].data[:] = Trim2FixedPoint_cpu(data, bitwidth, threshold, np.round)

    # Inputs
    net.forward(start = net.bottom_names[name][0], end = name)

    # Execute
    net.forward(start = name, end = name)

    # Outputs
    data = net.blobs[net.top_names[name][0]].data[...]
    bitwidth = bw_layer_in[net.top_names[name][0]]
    threshold = th_layer_in[net.top_names[name][0]]

    bw_layer_out[net.top_names[name][0]] = bitwidth
    th_layer_out[net.top_names[name][0]] = threshold

    net.blobs[net.top_names[name][0]].data[:] = Trim2FixedPoint_cpu(data, bitwidth, threshold, np.round)

    
    #print "bw_layer_in: ", bw_layer_in[net.top_names[name][0]]
    #print "th_layer_in: ", th_layer_in[net.top_names[name][0]]

    #L = next(L for L in net_parameter.layer if L.name == name)
    #L.quantization_param.bw_layer_in = bw_layer_in[net.top_names[name][0]]
    #L.quantization_param.th_layer_in = th_layer_in[net.top_names[name][0]]

    #print "bw_layer_out: ", bw_layer_out[net.top_names[name][0]]
    #print "th_layer_out: ", th_layer_out[net.top_names[name][0]]

    #L = next(L for L in net_parameter.layer if L.name == name)
    #L.quantization_param.bw_layer_out = bw_layer_out[net.top_names[name][0]]
    #L.quantization_param.th_layer_out = th_layer_out[net.top_names[name][0]]
    
    threshold_match_checker(th_layer_in[net.top_names[name][0]], th_layer_out[net.bottom_names[name][0]], name)
    return net, bw_layer_in, th_layer_in, bw_layer_out, th_layer_out

def quantize_pooling(name, net, net_parameter, bw_layer_in, th_layer_in, bw_layer_out, th_layer_out):
    # Inputs
    data = net.blobs[net.bottom_names[name][0]].data[...]
    bitwidth = bw_layer_out[net.bottom_names[name][0]]
    threshold = th_layer_out[net.bottom_names[name][0]]

    bw_layer_in[net.top_names[name][0]] = bitwidth
    th_layer_in[net.top_names[name][0]] = threshold

    net.blobs[net.bottom_names[name][0]].data[:] = Trim2FixedPoint_cpu(data, bitwidth, threshold, np.round)

    # Execute
    net.forward(start = name, end = name)

    # Outputs
    data = net.blobs[net.top_names[name][0]].data[...]
    bitwidth = bw_layer_in[net.top_names[name][0]]
    threshold = th_layer_in[net.top_names[name][0]]

    bw_layer_out[net.top_names[name][0]] = bitwidth
    th_layer_out[net.top_names[name][0]] = threshold

    net.blobs[net.top_names[name][0]].data[:] = Trim2FixedPoint_cpu(data, bitwidth, threshold, np.round)

    print "bw_layer_in: ", bw_layer_in[net.top_names[name][0]]
    print "th_layer_in: ", th_layer_in[net.top_names[name][0]]

    L = next(L for L in net_parameter.layer if L.name == name)
    L.quantization_param.quant_type = "Offline"
    L.quantization_param.bw_layer_in = bw_layer_in[net.top_names[name][0]]
    L.quantization_param.th_layer_in = th_layer_in[net.top_names[name][0]]

    print "bw_layer_out: ", bw_layer_out[net.top_names[name][0]]
    print "th_layer_out: ", th_layer_out[net.top_names[name][0]]

    L = next(L for L in net_parameter.layer if L.name == name)
    L.quantization_param.bw_layer_out = bw_layer_out[net.top_names[name][0]]
    L.quantization_param.th_layer_out = th_layer_out[net.top_names[name][0]]
    
    threshold_match_checker(th_layer_in[net.top_names[name][0]], th_layer_out[net.bottom_names[name][0]], name)
    return net, bw_layer_in, th_layer_in, bw_layer_out, th_layer_out

def quantize_dropout(name, net, net_parameter, bw_layer_in, th_layer_in, bw_layer_out, th_layer_out):
    # Inputs
    data = net.blobs[net.bottom_names[name][0]].data[...]
    bitwidth = bw_layer_out[net.bottom_names[name][0]]
    threshold = th_layer_out[net.bottom_names[name][0]]

    bw_layer_in[net.top_names[name][0]] = bitwidth
    th_layer_in[net.top_names[name][0]] = threshold

    net.blobs[net.bottom_names[name][0]].data[:] = Trim2FixedPoint_cpu(data, bitwidth, threshold, np.round)

    # Execute
    net.forward(start = name, end = name)

    # Outputs
    data = net.blobs[net.top_names[name][0]].data[...]
    bitwidth = bw_layer_in[net.top_names[name][0]]
    threshold = th_layer_in[net.top_names[name][0]]

    bw_layer_out[net.top_names[name][0]] = bitwidth
    th_layer_out[net.top_names[name][0]] = threshold

    net.blobs[net.top_names[name][0]].data[:] = Trim2FixedPoint_cpu(data, bitwidth, threshold, np.round)

    print "bw_layer_in: ", bw_layer_in[net.top_names[name][0]]
    print "th_layer_in: ", th_layer_in[net.top_names[name][0]]

    L = next(L for L in net_parameter.layer if L.name in net.top_names[name])
    L.quantization_param.bw_layer_in = bw_layer_in[net.top_names[name][0]]
    L.quantization_param.th_layer_in = th_layer_in[net.top_names[name][0]]

    #print "bw_layer_out: ", bw_layer_out[net.top_names[name][0]]
    #print "th_layer_out: ", th_layer_out[net.top_names[name][0]]

    #L = next(L for L in net_parameter.layer if L.name == name)
    #L.quantization_param.bw_layer_out = bw_layer_out[net.top_names[name][0]]
    #L.quantization_param.th_layer_out = th_layer_out[net.top_names[name][0]]
    
    threshold_match_checker(th_layer_in[net.top_names[name][0]], th_layer_out[net.bottom_names[name][0]], name)
    return net, bw_layer_in, th_layer_in, bw_layer_out, th_layer_out

def quantize_split(name, net, net_parameter, bw_layer_in, th_layer_in, bw_layer_out, th_layer_out):
    # Inputs
    for i in range(len(net.top_names[name])):
        bw_layer_in[net.top_names[name][i]] = bw_layer_out[net.bottom_names[name][0]]
        th_layer_in[net.top_names[name][i]] = th_layer_out[net.bottom_names[name][0]]

    # Execute
    net.forward(start = name, end = name)

    # Outputs
    for i in range(len(net.top_names[name])):
        bw_layer_out[net.top_names[name][i]] = bw_layer_in[net.top_names[name][i]]
        th_layer_out[net.top_names[name][i]] = th_layer_in[net.top_names[name][i]]

    #print "bw_layer_in: ", bw_layer_in[net.top_names[name][0]]
    #print "th_layer_in: ", th_layer_in[net.top_names[name][0]]

    #print "bw_layer_out: ", bw_layer_out[net.top_names[name][0]]
    #print "th_layer_out: ", th_layer_out[net.top_names[name][0]]
    
    threshold_match_checker(th_layer_in[net.top_names[name][0]], th_layer_out[net.bottom_names[name][0]], name)
    return net, bw_layer_in, th_layer_in, bw_layer_out, th_layer_out

def quantize_concat(name, net, net_parameter, bw_layer_in, th_layer_in, bw_layer_out, th_layer_out, bw_layer_out_global):
    # Inputs
    for bottom_name in net.bottom_names[name]:
        start_name = list(name for name, layer in net.layer_dict.iteritems() if bottom_name in net.top_names[name])[0]
        end_name = list(name for name, layer in net.layer_dict.iteritems() if bottom_name in net.top_names[name])[-1]
        net.forward(start = start_name, end = end_name)

    # Execute
    net.forward(start = name, end = name)

    # Outputs
    data = net.blobs[net.top_names[name][0]].data[...]
    bitwidth = bw_layer_out_global
    threshold = ThresholdLayerOutputs_cpu(data, bitwidth) #np.max(data).astype(float)

    bw_layer_out[net.top_names[name][0]] = bitwidth
    th_layer_out[net.top_names[name][0]] = threshold

    net.blobs[net.top_names[name][0]].data[:] = Trim2FixedPoint_cpu(data, bitwidth, threshold, np.round)

    # Backpropogate to Inputs
    bw_layer_in[net.top_names[name][0]] = bw_layer_out[net.top_names[name][0]]
    th_layer_in[net.top_names[name][0]] = th_layer_out[net.top_names[name][0]]

    # Backpropogate to Previous Outputs
    for bottom_name in net.bottom_names[name]:
        
        bottom_name = next(name for name, layer in net.layer_dict.iteritems() if bottom_name in net.top_names[name])
        bottom_layer = net.layers[list(net._layer_names).index(bottom_name)]
        
        # Handle SSD-case. Tailored solution. TODO: Generalize if possible
        if bottom_layer.type in ["Permute", "Flatten"]:
            
            bw_layer_out[net.top_names[bottom_name][0]] = bw_layer_in[net.top_names[name][0]]
            th_layer_out[net.top_names[bottom_name][0]] = th_layer_in[net.top_names[name][0]]

            L = next(L for L in net_parameter.layer if L.name in net.top_names[bottom_name])
            L.quantization_param.bw_layer_out = bw_layer_out[net.top_names[bottom_name][0]]
            L.quantization_param.th_layer_out = th_layer_out[net.top_names[bottom_name][0]]
            L.quantization_param.bw_layer_in = bw_layer_out[net.top_names[bottom_name][0]]
            L.quantization_param.th_layer_in = th_layer_out[net.top_names[bottom_name][0]] 
            
            #print "LEVEL#0: Value of bottom_layer var is " + str(bottom_name)
            name1 = bottom_name
            bottom_name = next(name1 for name1, layer in net.layer_dict.iteritems() if bottom_name in net.top_names[name1])
            bottom_layer = net.layers[list(net._layer_names).index(bottom_name)]
        
            
            for bottom_name in net.bottom_names[name1]:
                #print "LEVEL#1: Value of bottom_layer var is " + str(bottom_name)
                if bottom_layer.type in ["Permute", "Flatten"]:
            
                    bw_layer_out[net.top_names[bottom_name][0]] = bw_layer_in[net.top_names[name][0]]
                    th_layer_out[net.top_names[bottom_name][0]] = th_layer_in[net.top_names[name][0]]

                    L = next(L for L in net_parameter.layer if L.name in net.top_names[bottom_name])
                    L.quantization_param.bw_layer_out = bw_layer_out[net.top_names[bottom_name][0]]
                    L.quantization_param.th_layer_out = th_layer_out[net.top_names[bottom_name][0]]
                    L.quantization_param.bw_layer_in = bw_layer_out[net.top_names[bottom_name][0]]
                    L.quantization_param.th_layer_in = th_layer_out[net.top_names[bottom_name][0]] 
            
                    name1 = bottom_name
                    bottom_name = next(name1 for name1, layer in net.layer_dict.iteritems() if bottom_name in net.top_names[name1])
                    bottom_layer = net.layers[list(net._layer_names).index(bottom_name)]
                    
                    for bottom_name in net.bottom_names[name1]:
                        if bottom_layer.type in ["Permute", "Flatten"]:
                        
                            #print "LEVEL#2: Value of bottom_layer var is " + str(bottom_name)
                        
                            bw_layer_out[net.top_names[bottom_name][0]] = bw_layer_in[net.top_names[name][0]]
                            th_layer_out[net.top_names[bottom_name][0]] = th_layer_in[net.top_names[name][0]]

                            L = next(L for L in net_parameter.layer if L.name in net.top_names[bottom_name])
                            L.quantization_param.bw_layer_out = bw_layer_out[net.top_names[bottom_name][0]]
                            L.quantization_param.th_layer_out = th_layer_out[net.top_names[bottom_name][0]]
                        else:
                            pass
                else:
                    pass
        else:
            # Handle regular case for Concat layer
            bw_layer_out[net.top_names[bottom_name][0]] = bw_layer_in[net.top_names[name][0]]
            th_layer_out[net.top_names[bottom_name][0]] = th_layer_in[net.top_names[name][0]]

            L = next(L for L in net_parameter.layer if L.name in net.top_names[bottom_name])
            L.quantization_param.bw_layer_out = bw_layer_out[net.top_names[bottom_name][0]]
            L.quantization_param.th_layer_out = th_layer_out[net.top_names[bottom_name][0]]
            
                
    print "bw_layer_in: ", bw_layer_in[net.top_names[name][0]]
    print "th_layer_in: ", th_layer_in[net.top_names[name][0]]

    L = next(L for L in net_parameter.layer if L.name == name)
    L.quantization_param.quant_type = "Offline"
    L.quantization_param.bw_layer_in = bw_layer_in[net.top_names[name][0]]
    L.quantization_param.th_layer_in = th_layer_in[net.top_names[name][0]]

    print "bw_layer_out: ", bw_layer_out[net.top_names[name][0]]
    print "th_layer_out: ", th_layer_out[net.top_names[name][0]]

    L = next(L for L in net_parameter.layer if L.name == name)
    L.quantization_param.bw_layer_out = bw_layer_out[net.top_names[name][0]]
    L.quantization_param.th_layer_out = th_layer_out[net.top_names[name][0]]
    
    threshold_match_checker(th_layer_in[net.top_names[name][0]], th_layer_out[net.bottom_names[name][0]], name)
    return net, bw_layer_in, th_layer_in, bw_layer_out, th_layer_out

def quantize_eltwise(name, net, net_parameter, bw_layer_in, th_layer_in, bw_layer_out, th_layer_out):
    # Inputs
    bitwidth = bw_layer_out[net.bottom_names[name][0]]
    threshold = th_layer_out[net.bottom_names[name][0]]

    for i in range(1, len(net.bottom_names[name])):
        bitwidth = np.maximum(bitwidth, bw_layer_out[net.bottom_names[name][i]])
        threshold = np.maximum(threshold, th_layer_out[net.bottom_names[name][i]])

    bw_layer_in[net.top_names[name][0]] = bitwidth
    th_layer_in[net.top_names[name][0]] = threshold

    for i in range(1, len(net.bottom_names[name])):
        data = net.blobs[net.bottom_names[name][i]].data[...]
        net.blobs[net.bottom_names[name][i]].data[:] = Trim2FixedPoint_cpu(data, bitwidth, threshold, np.round)

    # Backpropogate to Previous Outputs(Skip if its another EltWise Layer)
    for bottom_name in net.bottom_names[name]:
       
        bottom_name = next(name for name, layer in net.layer_dict.iteritems() if bottom_name in net.top_names[name])
        bottom_layer = net.layers[list(net._layer_names).index(bottom_name)]
        if bottom_layer.type in ["Split"]:
           bottom_name = net.bottom_names[bottom_name][0]
           bw_layer_out[net.top_names[bottom_name][0]] = bw_layer_in[net.top_names[name][0]]
           th_layer_out[net.top_names[bottom_name][0]] = th_layer_in[net.top_names[name][0]]

           L = next(L for L in net_parameter.layer if L.name in net.top_names[bottom_name])
           L.quantization_param.bw_layer_out = bw_layer_out[net.top_names[bottom_name][0]]
           L.quantization_param.th_layer_out = th_layer_out[net.top_names[bottom_name][0]]
        elif bottom_layer.type in ["EltWise", "EltwiseRistretto"]:
            pass
        else:
            bw_layer_out[net.top_names[bottom_name][0]] = bw_layer_in[net.top_names[name][0]]
            th_layer_out[net.top_names[bottom_name][0]] = th_layer_in[net.top_names[name][0]]

            L = next(L for L in net_parameter.layer if L.name in net.top_names[bottom_name])
            L.quantization_param.bw_layer_out = bw_layer_out[net.top_names[bottom_name][0]]
            L.quantization_param.th_layer_out = th_layer_out[net.top_names[bottom_name][0]]

    # Execute
    net.forward(start = name, end = name)

    # Outputs
    data = net.blobs[net.top_names[name][0]].data[...]
    bitwidth = bw_layer_in[net.top_names[name][0]]
    threshold = th_layer_in[net.top_names[name][0]] #ThresholdLayerOutputs_cpu(data, bitwidth)

    bw_layer_out[net.top_names[name][0]] = bitwidth
    th_layer_out[net.top_names[name][0]] = threshold

    net.blobs[net.top_names[name][0]].data[:] = Trim2FixedPoint_cpu(data, bitwidth, threshold, np.round)

    print "bw_layer_in: ", bw_layer_in[net.top_names[name][0]]
    print "th_layer_in: ", th_layer_in[net.top_names[name][0]]

    L = next(L for L in net_parameter.layer if L.name == name)
    L.quantization_param.quant_type = "Offline"
    L.quantization_param.bw_layer_in = bw_layer_in[net.top_names[name][0]]
    L.quantization_param.th_layer_in = th_layer_in[net.top_names[name][0]]

    print "bw_layer_out: ", bw_layer_out[net.top_names[name][0]]
    print "th_layer_out: ", th_layer_out[net.top_names[name][0]]

    L = next(L for L in net_parameter.layer if L.name == name)
    L.quantization_param.bw_layer_out = bw_layer_out[net.top_names[name][0]]
    L.quantization_param.th_layer_out = th_layer_out[net.top_names[name][0]]
    #L.type = "EltwiseRistretto"
    
    threshold_match_checker(th_layer_in[net.top_names[name][0]], th_layer_out[net.bottom_names[name][0]], name)
    return net, bw_layer_in, th_layer_in, bw_layer_out, th_layer_out

def quantize_softmax(name, net, net_parameter, bw_layer_in, th_layer_in, bw_layer_out, th_layer_out):
    # Inputs
    data = net.blobs[net.bottom_names[name][0]].data[...]
    bitwidth = bw_layer_out[net.bottom_names[name][0]]
    threshold = th_layer_out[net.bottom_names[name][0]]

    bw_layer_in[net.top_names[name][0]] = bitwidth
    th_layer_in[net.top_names[name][0]] = threshold

    net.blobs[net.bottom_names[name][0]].data[:] = Trim2FixedPoint_cpu(data, bitwidth, threshold, np.round)

    # Execute
    net.forward(start = name, end = name)

    # Outputs
    #pass
    data = net.blobs[net.top_names[name][0]].data[...]
    bitwidth = bw_layer_in[net.top_names[name][0]] 
    threshold = ThresholdLayerOutputs_cpu(data, bitwidth) ## np.max(np.abs(data)) #Or simply take the max here???
        
    bw_layer_out[net.top_names[name][0]] = bitwidth
    th_layer_out[net.top_names[name][0]] = threshold
    
    net.blobs[net.top_names[name][0]].data[...] = Trim2FixedPoint_cpu(data, bitwidth, threshold, np.round)
    
    #print "bw_layer_in: ", bw_layer_in[net.top_names[name][0]]
    #print "th_layer_in: ", th_layer_in[net.top_names[name][0]]
    
    
    threshold_match_checker(th_layer_in[net.top_names[name][0]], th_layer_out[net.bottom_names[name][0]], name)
    return net, bw_layer_in, th_layer_in, bw_layer_out, th_layer_out


def quantize_deconvolution(name, net, net_parameter, bw_layer_in, th_layer_in, bw_layer_out, th_layer_out, bw_params, th_params, bw_params_global, bw_layer_out_global):
    
    # Inputs
    data = net.blobs[net.bottom_names[name][0]].data[...]
    bitwidth = bw_layer_out[net.bottom_names[name][0]]
    threshold = th_layer_out[net.bottom_names[name][0]]

    bw_layer_in[net.top_names[name][0]] = bitwidth
    th_layer_in[net.top_names[name][0]] = threshold

    net.blobs[net.bottom_names[name][0]].data[:] = Trim2FixedPoint_cpu(data, bitwidth, threshold, np.round)

    # Weights
    data = net.params[name][0].data[...]
    bitwidth = bw_params_global
    threshold = ThresholdWeights_cpu(data, bitwidth)

    bw_params[net.top_names[name][0]] = bitwidth
    th_params[net.top_names[name][0]] = threshold

    for i in range(len(th_params[net.top_names[name][0]])):
        net.params[name][0].data[i] = Trim2FixedPoint_cpu(data[i], bitwidth, threshold[i], np.round)

    # Execute
    net.forward(start = name, end = name)

    # Outputs
    data = net.blobs[net.top_names[name][0]].data[...]
    bitwidth = bw_layer_out_global
    threshold = ThresholdLayerOutputs_cpu(data, bitwidth) #np.max(data)#

    bw_layer_out[net.top_names[name][0]] = bitwidth
    th_layer_out[net.top_names[name][0]] = threshold

    net.blobs[net.top_names[name][0]].data[:] = Trim2FixedPoint_cpu(data, bitwidth, threshold, np.round)

    print "bw_layer_in: ", bw_layer_in[net.top_names[name][0]]
    print "th_layer_in: ", th_layer_in[net.top_names[name][0]]

    L = next(L for L in net_parameter.layer if L.name == name)
    L.quantization_param.quant_type = "Offline"
    L.quantization_param.bw_layer_in = bw_layer_in[net.top_names[name][0]]
    L.quantization_param.th_layer_in = th_layer_in[net.top_names[name][0]]

    print "bw_layer_out: ", bw_layer_out[net.top_names[name][0]]
    print "th_layer_out: ", th_layer_out[net.top_names[name][0]]

    L = next(L for L in net_parameter.layer if L.name == name)
    L.quantization_param.bw_layer_out = bw_layer_out[net.top_names[name][0]]
    L.quantization_param.th_layer_out = th_layer_out[net.top_names[name][0]].astype(float)
    

    L = next(L for L in net_parameter.layer if L.name == name)
    L.quantization_param.bw_params = bw_params[net.top_names[name][0]]
    L.quantization_param.th_params[:] = th_params[net.top_names[name][0]].astype(float)
    #L.type = "DeconvolutionRistretto"
    
    threshold_match_checker(th_layer_in[net.top_names[name][0]], th_layer_out[net.bottom_names[name][0]], name)
    return net, bw_layer_in, th_layer_in, bw_layer_out, th_layer_out, bw_params, th_params

def quantize_normalize(name, net, net_parameter, bw_layer_in, th_layer_in, bw_layer_out, th_layer_out, bw_params, th_params, bw_params_global, bw_layer_out_global):
    # Inputs
    data = net.blobs[net.bottom_names[name][0]].data[...]
    bitwidth = bw_layer_out[net.bottom_names[name][0]]
    threshold = th_layer_out[net.bottom_names[name][0]]

    bw_layer_in[net.top_names[name][0]] = bitwidth
    th_layer_in[net.top_names[name][0]] = threshold

    net.blobs[net.bottom_names[name][0]].data[:] = Trim2FixedPoint_cpu(data, bitwidth, threshold, np.round)

    # Weights
    data = net.params[name][0].data[...]
    bitwidth = bw_params_global
    threshold = data

    bw_params[net.top_names[name][0]] = bitwidth
    th_params[net.top_names[name][0]] = threshold

    for i in range(len(th_params[net.top_names[name][0]])):
        net.params[name][0].data[i] = Trim2FixedPoint_cpu(data[i], bitwidth, threshold[i], np.round)


    # Execute
    net.forward(start = name, end = name)

    # Outputs
    data = net.blobs[net.top_names[name][0]].data[...]
    bitwidth = bw_layer_in[net.top_names[name][0]]
    threshold = ThresholdLayerOutputs_cpu(data, bitwidth) #data.max() 

    bw_layer_out[net.top_names[name][0]] = bitwidth
    th_layer_out[net.top_names[name][0]] = threshold

    net.blobs[net.top_names[name][0]].data[:] = Trim2FixedPoint_cpu(data, bitwidth, threshold, np.round)

    print "bw_layer_in: ", bw_layer_in[net.top_names[name][0]]
    print "th_layer_in: ", th_layer_in[net.top_names[name][0]]

    L = next(L for L in net_parameter.layer if L.name == name)
    L.quantization_param.quant_type = "Offline"
    L.quantization_param.bw_layer_in = bw_layer_in[net.top_names[name][0]]
    L.quantization_param.th_layer_in = th_layer_in[net.top_names[name][0]]

    print "bw_layer_out: ", bw_layer_out[net.top_names[name][0]]
    print "th_layer_out: ", th_layer_out[net.top_names[name][0]]

    L = next(L for L in net_parameter.layer if L.name == name)
    L.quantization_param.bw_layer_out = bw_layer_out[net.top_names[name][0]]
    L.quantization_param.th_layer_out = th_layer_out[net.top_names[name][0]]
    L.quantization_param.bw_params = bw_params[net.top_names[name][0]]
    L.quantization_param.th_params[:] = th_params[net.top_names[name][0]].tolist()
    #L.type = "NormalizeRistretto"
    
    threshold_match_checker(th_layer_in[net.top_names[name][0]], th_layer_out[net.bottom_names[name][0]], name)
    return net, bw_layer_in, th_layer_in, bw_layer_out, th_layer_out

def quantize_permute(name, net, net_parameter, bw_layer_in, th_layer_in, bw_layer_out, th_layer_out):
    # Inputs
    data = net.blobs[net.bottom_names[name][0]].data[...]
    bitwidth = bw_layer_out[net.bottom_names[name][0]]
    threshold = th_layer_out[net.bottom_names[name][0]]

    bw_layer_in[net.top_names[name][0]] = bitwidth
    th_layer_in[net.top_names[name][0]] = threshold

    net.blobs[net.bottom_names[name][0]].data[:] = Trim2FixedPoint_cpu(data, bitwidth, threshold, np.round)

    # Execute
    net.forward(start = name, end = name)

    # Outputs
    data = net.blobs[net.top_names[name][0]].data[...]
    bitwidth = bw_layer_in[net.top_names[name][0]]
    threshold = th_layer_in[net.top_names[name][0]]

    bw_layer_out[net.top_names[name][0]] = bitwidth
    th_layer_out[net.top_names[name][0]] = threshold

    net.blobs[net.top_names[name][0]].data[:] = Trim2FixedPoint_cpu(data, bitwidth, threshold, np.round)

    print "bw_layer_in: ", bw_layer_in[net.top_names[name][0]]
    print "th_layer_in: ", th_layer_in[net.top_names[name][0]]

    for L in net_parameter.layer:
        if L.name == name:
            L.quantization_param.quant_type = "Offline"
            L.quantization_param.bw_layer_in = bw_layer_in[net.top_names[name][0]]
            L.quantization_param.th_layer_in = th_layer_in[net.top_names[name][0]]

    print "bw_layer_out: ", bw_layer_out[net.top_names[name][0]]
    print "th_layer_out: ", th_layer_out[net.top_names[name][0]]

    for L in net_parameter.layer:
        if L.name == name:
            L.quantization_param.bw_layer_out = bw_layer_out[net.top_names[name][0]]
            L.quantization_param.th_layer_out = th_layer_out[net.top_names[name][0]]
    
    threshold_match_checker(th_layer_in[net.top_names[name][0]], th_layer_out[net.bottom_names[name][0]], name)
    return net, bw_layer_in, th_layer_in, bw_layer_out, th_layer_out

def quantize_flatten_reshape(name, net, net_parameter, bw_layer_in, th_layer_in, bw_layer_out, th_layer_out):
    # Inputs
    data = net.blobs[net.bottom_names[name][0]].data[...]
    bitwidth = bw_layer_out[net.bottom_names[name][0]]
    threshold = th_layer_out[net.bottom_names[name][0]]

    bw_layer_in[net.top_names[name][0]] = bitwidth
    th_layer_in[net.top_names[name][0]] = threshold

    net.blobs[net.bottom_names[name][0]].data[:] = Trim2FixedPoint_cpu(data, bitwidth, threshold, np.round)

    # Execute
    net.forward(start = name, end = name)

    # Outputs
    data = net.blobs[net.top_names[name][0]].data[...]
    bitwidth = bw_layer_in[net.top_names[name][0]]
    threshold = th_layer_in[net.top_names[name][0]]

    bw_layer_out[net.top_names[name][0]] = bitwidth
    th_layer_out[net.top_names[name][0]] = threshold

    net.blobs[net.top_names[name][0]].data[:] = Trim2FixedPoint_cpu(data, bitwidth, threshold, np.round)

    #print "bw_layer_in: ", bw_layer_in[net.top_names[name][0]]
    #print "th_layer_in: ", th_layer_in[net.top_names[name][0]]

    #for L in net_parameter.layer:
        #if L.name == name:
            #L.quantization_param.bw_layer_in = bw_layer_in[net.top_names[name][0]]
            #L.quantization_param.th_layer_in = th_layer_in[net.top_names[name][0]]

    #print "bw_layer_out: ", bw_layer_out[net.top_names[name][0]]
    #print "th_layer_out: ", th_layer_out[net.top_names[name][0]]

    #for L in net_parameter.layer:
        #if L.name == name:
            #L.quantization_param.bw_layer_out = bw_layer_out[net.top_names[name][0]]
            #L.quantization_param.th_layer_out = th_layer_out[net.top_names[name][0]]
    
    threshold_match_checker(th_layer_in[net.top_names[name][0]], th_layer_out[net.bottom_names[name][0]], name)
    return net, bw_layer_in, th_layer_in, bw_layer_out, th_layer_out


# Throw a warning-message if previous layer's th_out is not equal to current layer's th_in
def threshold_match_checker(th_in_current, th_out_prev, name):
    if(th_in_current != th_out_prev):
        print "\n\n\nWARNING: Previous layer's th_out is not equal to current layer's " + name + "th_in."
        print "WARNING: A drop in accuracy may occur.\n\n\n"
    


# Declare and define network variables
def declare_network(deploy_model, weights):
    net = caffe.Net(deploy_model, weights, caffe.TEST)
    net_parameter = caffe.proto.caffe_pb2.NetParameter()
    return net, net_parameter

# Declare preprocessing transformations
def declare_transformer(net, transpose, channel_swap, raw_scale, mean_value, input_scale):
    transformer = caffe.io.Transformer({"data": net.blobs["data"].data.shape})
    transformer.set_transpose("data", transpose)
    transformer.set_channel_swap("data", channel_swap)
    transformer.set_raw_scale("data", raw_scale)
    transformer.set_mean("data", mean_value)
    transformer.set_input_scale("data", input_scale)
    return transformer

# Initialize and preprocess calibration samples
def initialize_calibration(net, calibration_size, dims, calibration_filenames, calibration_indices, transformer):
    net.blobs["data"].reshape(calibration_size, *dims)
    for i in range(calibration_size):
        print (calibration_filenames[calibration_indices[i]])
        data = caffe.io.load_image(calibration_filenames[calibration_indices[i]])
        net.blobs["data"].data[i] = transformer.preprocess("data", data)
    return net

def execute_calibration(net, net_parameter, bitwidths, deploy_model, quantized_deploy_model):
    # Declare quantization constants
    bw_layer_in_global = bitwidths[0]
    bw_params_global = bitwidths[1]
    bw_layer_out_global = bitwidths[2]

    # Declare quantization variables
    bw_layer_in = collections.OrderedDict()
    th_layer_in = collections.OrderedDict()
    bw_params = collections.OrderedDict()
    th_params = collections.OrderedDict()
    th_params_var = collections.OrderedDict()
    bw_layer_out = collections.OrderedDict()
    th_layer_out = collections.OrderedDict()

    with open(deploy_model, "r") as f, open(quantized_deploy_model, "w") as g:
        tfmt.Merge(f.read(), net_parameter)

        # Quantize layers accordingly in order
        for name, layer in net.layer_dict.iteritems():
            print "-" * 80
            print list(net._layer_names).index(name), len(list(net._layer_names))
            print name + ", " + layer.type
            print str(net.bottom_names[name]) + ", " + str(net.top_names[name])

            if layer.type in ["Input", "Data"]:
                net, bw_layer_out, th_layer_out = quantize_input(name, net, net_parameter, bw_layer_out_global, bw_layer_out, th_layer_out)
            elif layer.type in ["Convolution"]:
                net, bw_layer_in, th_layer_in, bw_layer_out, th_layer_out, bw_params, th_params = quantize_convolution(name, net, net_parameter, bw_layer_in, th_layer_in, bw_layer_out, th_layer_out, bw_params, th_params, bw_params_global, bw_layer_out_global)
            elif layer.type in ["InnerProduct"]:
                net, bw_layer_in, th_layer_in, bw_layer_out, th_layer_out, bw_params, th_params = quantize_inner_product(name, net, net_parameter, bw_layer_in, th_layer_in, bw_layer_out, th_layer_out, bw_params, th_params, bw_params_global, bw_layer_out_global)
            elif layer.type in ["ReLU"]:
                net, bw_layer_in, th_layer_in, bw_layer_out, th_layer_out = quantize_relu(name, net, net_parameter, bw_layer_in, th_layer_in, bw_layer_out, th_layer_out, bw_layer_out_global)
            elif layer.type in ["Pooling"]:
                net, bw_layer_in, th_layer_in, bw_layer_out, th_layer_out = quantize_pooling(name, net, net_parameter, bw_layer_in, th_layer_in, bw_layer_out, th_layer_out)
            elif layer.type in ["Dropout"]:
                net, bw_layer_in, th_layer_in, bw_layer_out, th_layer_out = quantize_dropout(name, net, net_parameter, bw_layer_in, th_layer_in, bw_layer_out, th_layer_out)
            elif layer.type in ["Split"]:
                net, bw_layer_in, th_layer_in, bw_layer_out, th_layer_out = quantize_split(name, net, net_parameter, bw_layer_in, th_layer_in, bw_layer_out, th_layer_out)
            elif layer.type in ["Concat"]:
                net, bw_layer_in, th_layer_in, bw_layer_out, th_layer_out = quantize_concat(name, net, net_parameter, bw_layer_in, th_layer_in, bw_layer_out, th_layer_out, bw_layer_out_global)
            elif layer.type in ["Eltwise"]:
                net, bw_layer_in, th_layer_in, bw_layer_out, th_layer_out = quantize_eltwise(name, net, net_parameter, bw_layer_in, th_layer_in, bw_layer_out, th_layer_out)
            elif layer.type in ["Softmax", "SoftmaxWithLoss"]:
                net, bw_layer_in, th_layer_in, bw_layer_out, th_layer_out = quantize_softmax(name, net, net_parameter, bw_layer_in, th_layer_in, bw_layer_out, th_layer_out)
            elif layer.type in ["Deconvolution"]:
                net, bw_layer_in, th_layer_in, bw_layer_out, th_layer_out, bw_params, th_params = quantize_deconvolution(name, net, net_parameter, bw_layer_in, th_layer_in, bw_layer_out, th_layer_out, bw_params, th_params, bw_params_global, bw_layer_out_global)
            elif layer.type in ["Normalize"]:
                net, bw_layer_in, th_layer_in, bw_layer_out, th_layer_out = quantize_normalize(name, net, net_parameter, bw_layer_in, th_layer_in, bw_layer_out, th_layer_out, bw_params, th_params, bw_params_global, bw_layer_out_global)
            elif layer.type in ["Permute"]:
                net, bw_layer_in, th_layer_in, bw_layer_out, th_layer_out = quantize_permute(name, net, net_parameter, bw_layer_in, th_layer_in, bw_layer_out, th_layer_out)
            elif layer.type in ["Flatten", "Reshape"]:
                net, bw_layer_in, th_layer_in, bw_layer_out, th_layer_out = quantize_flatten_reshape(name, net, net_parameter, bw_layer_in, th_layer_in, bw_layer_out, th_layer_out)
            elif layer.type in ["BatchNorm"]:
                net, bw_layer_in, th_layer_in, bw_layer_out, th_layer_out, bw_params, th_params = quantize_batchnorm(name, net, net_parameter, bw_layer_in, th_layer_in, bw_layer_out, th_layer_out, bw_params, th_params, th_params_var, bw_params_global, bw_layer_out_global)
            elif layer.type in ["Scale"]:
                net, bw_layer_in, th_layer_in, bw_layer_out, th_layer_out, bw_params, th_params = quantize_scale(name, net, net_parameter, bw_layer_in, th_layer_in, bw_layer_out, th_layer_out, bw_params, th_params, bw_params_global, bw_layer_out_global)
            else:
                print "Error: Quantization of " + layer.type + " is not yet supported"

        #print net_parameter
        g.write(tfmt.MessageToString(net_parameter))

#        if os.path.isfile(quantized_weights):
#            os.remove(quantized_weights)
#        net.save(quantized_weights)

def save_to_json(quantized_deploy_model, net, net_parameter):
    json_payload = {}
    json_payload["network"] = []

    with open(quantized_deploy_model, "r") as f, open(quantized_deploy_model.replace("prototxt", "json"), "w") as g:
        tfmt.Merge(f.read(), net_parameter)

        for name, layer in net.layer_dict.iteritems():
            if layer.type in ["Convolution", "InnerProduct"]:
                L = next(L for L in net_parameter.layer if L.name in net.top_names[name])

                bw_layer_in = np.array(L.quantization_param.bw_layer_in)
                th_layer_in = np.array(L.quantization_param.th_layer_in)

                bw_layer_out = np.array(L.quantization_param.bw_layer_out)
                th_layer_out = np.array(L.quantization_param.th_layer_out)

                bw_params = np.array(L.quantization_param.bw_params)
                th_params = np.array(L.quantization_param.th_params)

                sf_layer_in = th_layer_in / (pow(2, bw_layer_in - 1) - 1)
                sf_layer_out = th_layer_out / (pow(2, bw_layer_out - 1) - 1)
                sf_params = th_params / (pow(2, bw_params - 1) - 1)

                prescale_shift = np.floor(-np.log2(sf_layer_in * sf_params / sf_layer_out)).astype(int)
                scale = np.round(sf_layer_in * sf_params / sf_layer_out * pow(2, prescale_shift + 8 - 1)).astype(int)
                postscale_shift = np.repeat([8 - 1], scale.size)

                json_payload["network"].append({
                    "name" : name,
                    "bw_layer_in" : bw_layer_in.tolist(),
                    "bw_layer_out" : bw_layer_out.tolist(),
                    "bw_params" : bw_params.tolist(),
                    "th_layer_in" : th_layer_in.tolist(),
                    "th_layer_out" : th_layer_out.tolist(),
                    "th_params" : th_params.tolist(),
                    "sf_layer_in" : sf_layer_in.tolist(),
                    "sf_layer_out" : sf_layer_out.tolist(),
                    "sf_params" : sf_params.tolist(),
                    "prescale_shift" : prescale_shift.tolist(),
                    "scale" : scale.tolist(),
                    "postscale_shift" : postscale_shift.tolist()
                })

        json.dump(json_payload, g, indent=4, sort_keys=True)

def main(argv):
    pycaffe_dir = os.path.dirname(__file__)

    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--deploy_model",
        default=os.path.join(pycaffe_dir,
                "../models/bvlc_googlenet_without_lrn/bvlc_googlenet_without_lrn_deploy.prototxt"),
        help="Input prototxt for calibration"
    )
    #parser.add_argument(
        #"--train_val_model",
        #default=os.path.join(pycaffe_dir,
                #"../models/bvlc_googlenet_without_lrn/bvlc_googlenet_without_lrn_train_val.prototxt"),
        #help="Input training prototxt for calibration"
    #)
    parser.add_argument(
        "--weights",
        default=os.path.join(pycaffe_dir,
                "../models/bvlc_googlenet_without_lrn/bvlc_googlenet_without_lrn.caffemodel"),
        help="FP32 pretrained caffe model"
    )
    parser.add_argument(
        "--quantized_deploy_model",
        default=os.path.join(pycaffe_dir,
                "../models/bvlc_googlenet_without_lrn/RistrettoDemo/bvlc_googlenet_without_lrn_quantized_deploy.prototxt"),
        help="Output file name for calibration-deploy"
    )
    #parser.add_argument(
        #"--quantized_train_val_model",
        #default=os.path.join(pycaffe_dir,
                #"../models/bvlc_googlenet_without_lrn/RistrettoDemo/bvlc_googlenet_without_lrn_quantized_train_val.prototxt"),
        #help="Output file name for calibration-train-val"
    #)
    parser.add_argument(
        "--quantized_weights",
        default=os.path.join(pycaffe_dir,
                "../models/bvlc_googlenet_without_lrn/RistrettoDemo/bvlc_googlenet_without_lrn_quantized.caffemodel"),
        help="Output file name for calibration-weights"
    )
    parser.add_argument(
        "--calibration_directory",
        default="/data/caffe/data/ilsvrc12/ILSVRC2012_img_val",
        help="Dir of dataset of original images"
    )
    parser.add_argument(
        "--calibration_size",
        type=int,
        default=8,
        help="Number of images to use for calibration, default is 8"

    )
    parser.add_argument(
        "--calibration_indices",
        default=None,
    )
    parser.add_argument(
        "--bitwidths",
        default="8,8,8",
        help="Bit widths for input,params,output default: 8,8,8"
    )
    parser.add_argument(
        "--dims",
        default="3,224,224",
        help="Dimensions for first layer, default 3,224,224"
    )
    parser.add_argument(
        "--transpose",
        default="2,0,1",
        help="Passed to caffe.io.Transformer function set_transpose, default 2,0,1"
    )
    parser.add_argument(
        "--channel_swap",
        default="2,1,0",
        help="Passed to caffe.io.Transformer function set_channel_swap, default 2,1,0"
    )
    parser.add_argument(
        "--raw_scale",
        type=float,
        default=255.0,
        help="Passed to caffe.io.Transformer function set_raw_scale, default 255.0"
    )
    parser.add_argument(
        "--mean_value",
        default="104,117,123",
        help="Passed to caffe.io.Transformer function set_mean, default 104,117,123"
    )
    parser.add_argument(
        "--input_scale",
        type=float,
        default=1.0,
        help="Passed to caffe.io.Transformer function set_input_scale, default 1.0"
    )
    parser.add_argument(
        "--gpu",
        action="store_true",
        help="Setting this would assume GPU available and built for Caffe, default device is set to CPU"
    )
    args = parser.parse_args()

    deploy_model = None
    if args.deploy_model:
        deploy_model = args.deploy_model

    #train_val_model = None
    #if args.train_val_model:
        #train_val_model = args.train_val_model

    weights = None
    if args.weights:
        weights = args.weights

    quantized_deploy_model = None
    if args.quantized_deploy_model:
        quantized_deploy_model = args.quantized_deploy_model

    #quantized_train_val_model = None
    #if args.quantized_train_val_model:
        #quantized_train_val_model = args.quantized_train_val_model

    quantized_weights = None
    if args.quantized_weights:
        quantized_weights = args.quantized_weights

    calibration_directory = None
    if args.calibration_directory:
        calibration_directory = args.calibration_directory

    calibration_filenames = os.listdir(calibration_directory)
    #for calibration_filename in calibration_filenames:
    #    calibration_filename = os.path.join(calibration_directory, calibration_filename)
    for i in range(0, len(calibration_filenames)):
        calibration_filenames[i] = os.path.join(calibration_directory, calibration_filenames[i])

    calibration_size = None
    if args.calibration_size:
        calibration_size = int(args.calibration_size)
        if (calibration_size > len(calibration_filenames)):
            sys.stderr.write("Requested calibration size is greater than the number of available files in the specified calibration directory\n")
            quit(1)

    calibration_indices = None
    extra_calibration_indices = None
    if args.calibration_indices:
        calibration_indices = np.array([int(s) for s in args.calibration_indices.split(",")])
        remaining_array = np.setdiff1d(np.arange(0, len(calibration_filenames)), calibration_indices)
        extra_calibration_indices = np.sort(np.random.choice(remaining_array, calibration_size - len(calibration_indices), replace = False))
        calibration_indices = np.sort(np.append(calibration_indices, extra_calibration_indices))
    else:
        calibration_indices = np.sort(np.random.choice(range(len(calibration_filenames)), calibration_size, replace = False))

    bitwidths = None
    if args.bitwidths:
        bitwidths = [int(s) for s in args.bitwidths.split(",")]

    dims = None
    if args.dims:
        dims = [int(s) for s in args.dims.split(",")]

    transpose = None
    if args.transpose:
        transpose = [int(s) for s in args.transpose.split(",")]

    channel_swap = None
    if args.channel_swap:
        channel_swap = [int(s) for s in args.channel_swap.split(",")]

    raw_scale = None
    if args.raw_scale:
        raw_scale = float(args.raw_scale)

    mean_value = None
    if args.mean_value:
        mean_value_list = [float(s) for s in args.mean_value.split(",")]
        mean_value = np.array(mean_value_list)

    input_scale = None
    if args.input_scale:
        input_scale = float(args.input_scale)

    if args.gpu:
        caffe.set_mode_gpu()
    else:
        caffe.set_mode_cpu()

    calibration_indices_str = ",".join(map(str, calibration_indices))
    if args.gpu:
        print sys.argv[0], "--deploy_model", args.deploy_model, "--weights", args.weights, "--quantized_deploy_model", args.quantized_deploy_model, "--quantized_weights", args.quantized_weights, "--calibration_directory", args.calibration_directory, "--calibration_size", args.calibration_size, "--calibration_indices", calibration_indices_str, "--bitwidths", args.bitwidths, "--dims", args.dims, "--transpose", args.transpose, "--channel_swap", args.channel_swap, "--raw_scale", args.raw_scale, "--mean_value", args.mean_value, "--input_scale", args.input_scale, "--gpu "
    else:
        print sys.argv[0], "--deploy_model", args.deploy_model, "--weights", args.weights, "--quantized_deploy_model", args.quantized_deploy_model, "--quantized_weights", args.quantized_weights, "--calibration_directory", args.calibration_directory, "--calibration_size", args.calibration_size, "--calibration_indices", calibration_indices_str, "--bitwidths", args.bitwidths, "--dims", args.dims, "--transpose", args.transpose, "--channel_swap", args.channel_swap, "--raw_scale", args.raw_scale, "--mean_value", args.mean_value, "--input_scale", args.input_scale

    net, net_parameter = declare_network(deploy_model, weights)
    transformer = declare_transformer(net, transpose, channel_swap, raw_scale, mean_value, input_scale)
    net = initialize_calibration(net, calibration_size, dims, calibration_filenames, calibration_indices, transformer);
    
    #TODO: Use deploy itself for calibration as well
    execute_calibration(net, net_parameter, bitwidths, deploy_model, quantized_deploy_model)
    #save_to_json(quantized_train_val_model, net, net_parameter)

    calibration_indices_str = ",".join(map(str, calibration_indices))
    if args.gpu:
        print sys.argv[0], "--deploy_model", args.deploy_model, "--weights", args.weights, "--quantized_deploy_model", args.quantized_deploy_model, "--quantized_weights", args.quantized_weights, "--calibration_directory", args.calibration_directory, "--calibration_size", args.calibration_size, "--calibration_indices", calibration_indices_str, "--bitwidths", args.bitwidths, "--dims", args.dims, "--transpose", args.transpose, "--channel_swap", args.channel_swap, "--raw_scale", args.raw_scale, "--mean_value", args.mean_value, "--input_scale", args.input_scale, "--gpu "
    else:
        print sys.argv[0], "--deploy_model", args.deploy_model, "--weights", args.weights, "--quantized_deploy_model", args.quantized_deploy_model, "--quantized_weights", args.quantized_weights, "--calibration_directory", args.calibration_directory, "--calibration_size", args.calibration_size, "--calibration_indices", calibration_indices_str, "--bitwidths", args.bitwidths, "--dims", args.dims, "--transpose", args.transpose, "--channel_swap", args.channel_swap, "--raw_scale", args.raw_scale, "--mean_value", args.mean_value, "--input_scale", args.input_scale

if __name__ == "__main__":
    main(sys.argv)

